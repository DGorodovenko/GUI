package view;

import javax.swing.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Diagram
{
    private static final int MAX_INDEX = 4;

    public static void main(String[] args)
    {
        JFrame f = new JFrame("Відношення зарплат співробітників");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        AtomicInteger position = new AtomicInteger();
        DiagramButton diagramButton = new DiagramButton(position);

        diagramButton.addActionListener(e -> {
            position.getAndIncrement();

            if(position.get() > MAX_INDEX) {
                position.set(0);
            }

            f.getContentPane().add(new DiagramButton(position));
        });

        f.getContentPane().add(diagramButton);


        f.setSize(550,500);
        f.setLocation(550,500);
        f.setVisible(true);
    }
}