import java.io.*;

public class Square extends Geometricprimitive{

 private final double side;
    public Square() { this(1); }
    public Square(double side) { this.side = side; }

@Override
  public double area() { return side * side; }

  public double perimeter() { return 4 * side; }

    @Override
    public void serialize(OutputStream output) {
        try
        {
            String s="square side=" + side + "\r\n";
            byte b[]=s.getBytes();
            output.write(b);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public static Geometricprimitive deserialize(InputStream input) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            if (reader.ready()) {
                String line = reader.readLine();
                String[] lines = line.split(" ");
                double side = 0;
                for (int i = 1; i < lines.length; i++){
                    switch (lines[i].split("=")[0]){
                        case "side": side = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        default: return null;
                    }
                }
                return new Square(side);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}