import java.io.*;

public class Triangle extends Geometricprimitive {
    private final double a, b, c; 

    public Triangle() {
        this(1,1,1);
    }
    public Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public double area() {
        double s = (a + b + c) / 2;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }

    @Override
    public double perimeter() {
        return a + b + c;
    }

    @Override
    public void serialize(OutputStream output) {
        try
        {
            String s="triangle a=" + a + " b=" + b + " c=" + c + "\r\n";
            byte b[]=s.getBytes();
            output.write(b);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public static Geometricprimitive deserialize(InputStream input) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            if (reader.ready()) {
                String line = reader.readLine();
                String[] lines = line.split(" ");
                double a = 0, b = 0, c = 0;
                for (int i = 1; i < lines.length; i++) {
                    switch (lines[i].split("=")[0]) {
                        case "a":
                            a = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "b":
                            b = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "c":
                            c = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        default:
                            return null;
                    }
                }
                return new Triangle(a, b, c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
