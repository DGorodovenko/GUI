import java.io.*;

public class Diamond extends Geometricprimitive{
 
    private double ad;
    private double p;
    private double q;
    
    public Diamond() {
      this(1,1,1);
   }
    public Diamond(double ad, double p, double q) {
      this.ad = ad;
      this.p = p;
      this.q = q;
      
   }
  @Override
  public double area() {
      return ad * 4;
  }

  @Override
  public double perimeter() {
      return (p*q)/2;
  }

    @Override
    public void serialize(OutputStream output) {
        try
        {
            String s="diamond p=" + p + " q=" + q + " ad=" + ad + "\r\n";
            byte b[]=s.getBytes();
            output.write(b);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public static Geometricprimitive deserialize(InputStream input)  {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            if (reader.ready()) {
                String line = reader.readLine();
                String[] lines = line.split(" ");
                double ad = 0, p = 0, q = 0;
                for (int i = 1; i < lines.length; i++){
                    switch (lines[i].split("=")[0]){
                        case "ad": ad = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "p": p = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "q": q = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        default: return null;
                    }
                }
                return new Diamond(ad, p, q);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}