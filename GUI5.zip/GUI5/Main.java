import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static final String FILE_PATH = "<FILE_PATH>";

    public static void main(String[] args) {
        double width = 5;
        double length = 7;
        Geometricprimitive rectangle = new Rectangle(width, length);
//        rectangle.serialize();
        System.out.println("Rectangle width: " + width + " and length: " + length
                + "\nResulting area: " + rectangle.area()
                + "\nResulting perimeter: " + rectangle.perimeter() + "\n");

        double side = 5;
        Geometricprimitive square = new Square(side);
        System.out.println("Square width: " + side + " and length: " + side
                + "\nResulting area: " + square.area()
                + "\nResulting perimeter: " + square.perimeter() + "\n");

        // Circle test
        double radius = 5;
        Geometricprimitive circle = new Circle(radius);
        System.out.println("Circle radius: " + radius
                + "\nResulting Area: " + circle.area()
                + "\nResulting Perimeter: " + circle.perimeter() + "\n");

        // Triangle test
        double a = 5, b = 3, c = 4;
        Geometricprimitive triangle = new Triangle(a, b, c);
        System.out.println("Triangle sides lengths: " + a + ", " + b + ", " + c
                + "\nResulting Area: " + triangle.area()
                + "\nResulting Perimeter: " + triangle.perimeter() + "\n");

        //Trapezum
        double sideA = 5, sideB = 3, sideC = 4, sideD = 8, heightT = 4;
        Geometricprimitive trapezum = new Trapezium(sideA, sideB, sideC, sideD, heightT);
        System.out.println("Trapezum sides lengths: " + sideA + ", " + sideB + ", " + sideC + ", "
                + sideD + " and height: " + heightT + "\nResulting Area: " + trapezum.area()
                + "\nResulting Perimeter: " + trapezum.perimeter() + "\n");

        //
        //Trapezum
        double base = 5, sideP = 3, heightP = 4;
        Geometricprimitive parallelogram = new Parallelogram(base, sideP, heightP);
        System.out.println("Parallelogram sides lengths: " + base + ", " + sideP + ", " + " and height: " + heightP + "\nResulting Area: " + parallelogram.area()
                + "\nResulting Perimeter: " + parallelogram.perimeter() + "\n");

        double ad = 5, q = 3, p = 4;
        Geometricprimitive diamond = new Diamond(ad, p, q);
        System.out.println("Diamond diagonals lengths: " + p + ", " + q + ", " + " and side: " + ad + "\nResulting Area: " + diamond.area()
                + "\nResulting Perimeter: " + diamond.perimeter() + "\n");

        try {
            OutputStream output = new FileOutputStream(FILE_PATH);
            rectangle.serialize(output);
            square.serialize(output);
            circle.serialize(output);
            triangle.serialize(output);
            trapezum.serialize(output);
            parallelogram.serialize(output);
            diamond.serialize(output);
            output.close();
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<Geometricprimitive> primitives = new ArrayList<>();
        try {
            InputStream input = new FileInputStream(FILE_PATH);
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            Geometricprimitive item = null;

            if (reader.ready()) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] lineData = line.split(" ");
                    switch (lineData[0]) {
                        case "circle":
                            item = Circle.deserialize(new ByteArrayInputStream(line.getBytes(StandardCharsets.UTF_8)));
                            System.out.println("Circle" + "\nResulting Area: " + item.area()
                                    + "\nResulting Perimeter: " + item.perimeter() + "\n");
                            break;
                        case "diamond":
                            item = Diamond.deserialize(new ByteArrayInputStream(line.getBytes(StandardCharsets.UTF_8)));
                            System.out.println("Diamond" + "\nResulting Area: " + item.area()
                                    + "\nResulting Perimeter: " + item.perimeter() + "\n");
                            break;
                        case "parallelogram":
                            item = Parallelogram.deserialize(new ByteArrayInputStream(line.getBytes(StandardCharsets.UTF_8)));
                            System.out.println("Parallelogram" + "\nResulting Area: " + item.area()
                                    + "\nResulting Perimeter: " + item.perimeter() + "\n");
                            break;
                        case "rectangle":
                            item = Rectangle.deserialize(new ByteArrayInputStream(line.getBytes(StandardCharsets.UTF_8)));
                            System.out.println("Rectangle" + "\nResulting area: " + item.area()
                                    + "\nResulting perimeter: " + item.perimeter() + "\n");
                            break;
                        case "square":
                            item = Square.deserialize(new ByteArrayInputStream(line.getBytes(StandardCharsets.UTF_8)));
                            System.out.println("Square" + "\nResulting area: " + item.area()
                                    + "\nResulting perimeter: " + item.perimeter() + "\n");
                            break;
                        case "trapezium":
                            item = Trapezium.deserialize(new ByteArrayInputStream(line.getBytes(StandardCharsets.UTF_8)));
                            System.out.println("Trapezum" + "\nResulting Area: " + item.area()
                                + "\nResulting Perimeter: " + item.perimeter() + "\n");
                            break;
                        case "triangle":
                            item = Triangle.deserialize(new ByteArrayInputStream(line.getBytes(StandardCharsets.UTF_8)));
                            System.out.println("Triangle" + "\nResulting Area: " + item.area()
                                    + "\nResulting Perimeter: " + item.perimeter() + "\n");
                            break;
                        default:
                            item = null;
                    }
                    if (item != null) {
                        primitives.add(item);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}