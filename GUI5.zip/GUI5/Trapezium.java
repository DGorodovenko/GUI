import java.io.*;

public class Trapezium extends Geometricprimitive {

    private final double sideA, sideB, sideC, sideD, heightT;

    public Trapezium() {
        this(1, 1, 1, 1, 1);
    }

    public Trapezium(double sideA, double sideB, double sideC, double sideD, double heightT) {
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
        this.sideD = sideD;
        this.heightT = heightT;
    }

    @Override
    public double area() {
        return ((sideA + sideB) / 2) * heightT;
    }

    @Override
    public double perimeter() {
        return sideA + sideB + sideC + sideD;
    }

    @Override
    public void serialize(OutputStream output) {
        try {
            String s = "trapezium sideA=" + sideA + " sideB=" + sideB + " sideC=" + sideC
                    + " sideD=" + sideD + " heightT=" + heightT + "\r\n";
            byte b[] = s.getBytes();
            output.write(b);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static Geometricprimitive deserialize(InputStream input) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            if (reader.ready()) {
                String line = reader.readLine();
                String[] lines = line.split(" ");
                double sideA = 0, sideB = 0, sideC = 0, sideD = 0, heightT = 0;
                for (int i = 1; i < lines.length; i++){
                    switch (lines[i].split("=")[0]){
                        case "sideA": sideA = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "sideB": sideB = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "sideC": sideC = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "sideD": sideD = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "heightT": heightT = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        default: return null;
                    }
                }
                return new Trapezium(sideA, sideB, sideC, sideD, heightT);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}