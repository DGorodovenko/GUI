
public abstract class Geometricprimitive implements GeometricprimitiveSerializer {

    public abstract double area();
    public abstract double perimeter();

}