import java.io.*;

public class Rectangle extends Geometricprimitive{
 
    private final double width, length;
    
    public Rectangle() {
      this(1,1);
   }
    public Rectangle(double width, double length) {
      this.width = width;
      this.length = length;
   }
  @Override
  public double area() {
      return width * length;
  }

  @Override
  public double perimeter() {
      return 2 * (width + length);
  }

    @Override
    public void serialize(OutputStream output) {
        try
        {
            String s="rectangle width=" + width + " length=" + length + "\r\n";
            byte b[]=s.getBytes();
            output.write(b);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public static Geometricprimitive deserialize(InputStream input) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            if (reader.ready()) {
                String line = reader.readLine();
                String[] lines = line.split(" ");
                double width = 0, length = 0;
                for (int i = 1; i < lines.length; i++){
                    switch (lines[i].split("=")[0]){
                        case "width": width = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "length": length = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        default: return null;
                    }
                }
                return new Rectangle(width, length);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}