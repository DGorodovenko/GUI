import java.io.*;

class Parallelogram extends Geometricprimitive {

    private double sideP;
    private double base;
    private final double heightP;

    public Parallelogram() {
        this(1, 1, 1);
    }

    public Parallelogram(double sideP, double base, double heightP) {
        this.sideP = sideP;
        this.base = base;
        this.heightP = heightP;
    }

    @Override
    public double area() {
        return base * heightP;
    }

    @Override
    public double perimeter() {
        return 2 * (sideP + base);
    }

    @Override
    public void serialize(OutputStream output) {
        try {
            String s = "parallelogram base=" + base + " sideP=" + sideP
                    + " heightP=" + heightP + "\r\n";
            byte b[] = s.getBytes();
            output.write(b);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static Geometricprimitive deserialize(InputStream input) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            if (reader.ready()) {
                String line = reader.readLine();
                String[] lines = line.split(" ");
                double sideP = 0, base = 0, heightP = 0;
                for (int i = 1; i < lines.length; i++) {
                    switch (lines[i].split("=")[0]) {
                        case "sideP":
                            sideP = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "base":
                            base = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        case "heightP":
                            heightP = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        default:
                            return null;
                    }
                }
                return new Parallelogram(sideP, base, heightP);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}