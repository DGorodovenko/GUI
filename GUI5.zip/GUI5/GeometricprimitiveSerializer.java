import java.io.InputStream;
import java.io.OutputStream;

public interface GeometricprimitiveSerializer {
    static Geometricprimitive deserialize(InputStream input) {
        return null;
    }

    void serialize(OutputStream output);
}
