import java.io.*;
import java.nio.charset.StandardCharsets;

public class Circle extends Geometricprimitive {
    private double radius;
    final double pi = Math.PI;

    public Circle() {
        this(1);
    }   
    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double area() {
        return pi * Math.pow(radius, 2);
    }

    public double perimeter() {
        return 2 * pi * radius;
    }

    @Override
    public void serialize(OutputStream output) {
        try
        {
            String s="circle radius=" + radius + "\r\n";
            byte b[]=s.getBytes();
            output.write(b);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public static Geometricprimitive deserialize(InputStream input) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            if (reader.ready()) {
                String line = reader.readLine();
                String[] lines = line.split(" ");
                double radius = 0;
                for (int i = 1; i < lines.length; i++) {
                    switch (lines[i].split("=")[0]) {
                        case "radius":
                            radius = Double.parseDouble(lines[i].split("=")[1]);
                            break;
                        default:
                            return null;
                    }
                }
                return new Circle(radius);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}