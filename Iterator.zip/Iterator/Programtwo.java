import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class Programtwo {
 
    public static void main(String[] args) {
         
        ArrayList<String> states = new ArrayList<String>();
        states.add("Item1");
        states.add("Item2");
        states.add("Item3");
        states.add("Item4");

        System.out.println("Good order:");
        for (String state : states) {
            System.out.println(state);
        }
         
        ListIterator<String> listIterator = states.listIterator();
        while (listIterator.hasNext()) {
            String element = listIterator.next();
            listIterator.set(element);
        }

        System.out.print("Vica versa: \n" );
        while (listIterator.hasPrevious()) {
            String element = listIterator.previous();
            System.out.print(element + "\n");
    }


}

    public static class IteratorTest {

        private List<String> list;
        private List<String> listT;
        private Iterator<String> itr;
        private Iterator<String> itr2;

        @Before
        public void setUp()
        {
            list = new ArrayList<String>();
            list.add("item1");
            list.add("item2");
            list.add("item3");
            list.add("item4");
            itr2 = list.iterator();

        }

        @Test
        public void testHasNext_BaseCase() {
            assertTrue(itr2.hasNext());
            System.out.println("Good!");
        }

        @Test public void testNext_BaseCase()
        {
            assertEquals ("item1", itr2.next());
        }
        @Test
        public void testHasPrev() {
            ListIterator<String> listIterator = list.listIterator();
            assertFalse(listIterator.hasPrevious());
        }

    }
}