import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.*;

public class RectangleTest {
    Rectangle rectangle = new Rectangle(5,7 );
    @DisplayName("Area")
    @Test
    public void area() {
        assertEquals(35, rectangle.area(),1);
    }
    @DisplayName("Perimeter")
    @Test
    public void perimeter() {
        assertEquals(24,rectangle.perimeter(), 1);
    }
}