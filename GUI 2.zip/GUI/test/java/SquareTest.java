import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.*;

public class SquareTest {
    Square square = new Square(5);
    @DisplayName("Area")
    @Test
    public void area() {
        assertEquals(25.0,square.area(), 1);
    }

    @DisplayName("Perimeter")
    @Test
    public void perimeter() {
        assertEquals(20.0,square.perimeter(),1);
    }
}