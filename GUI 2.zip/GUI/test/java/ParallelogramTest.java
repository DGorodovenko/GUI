import org.junit.Test;

import static org.junit.Assert.*;

public class ParallelogramTest {
    Parallelogram parallelogram = new Parallelogram(5,4,3);
    @Test
    public void area() {
        assertEquals(12, parallelogram.area(),1);
    }

    @Test
    public void perimeter() {
        assertEquals(18, parallelogram.perimeter(),1);
    }
}