import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.*;

public class TrapeziumTest {

    Trapezium trapezium = new Trapezium(5,3,4,8,4);

    @DisplayName("Area")
    @Test
    public void area() {
        assertEquals(16, trapezium.area(),1);
    }

    @DisplayName("Perimeter")
    @Test
    public void perimeter() {
        assertEquals(20, trapezium.perimeter(),1);
    }
}