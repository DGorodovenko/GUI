import org.junit.Test;

import static org.junit.Assert.*;

public class DiamondTest {
    Diamond diamond = new Diamond(5,3,4);

    @Test
    public void area() {
        assertEquals(20,diamond.area(),1);
    }

    @Test
    public void perimeter() {
        assertEquals(6, diamond.perimeter(),1);
    }
}