import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.*;

public class TriangleTest {
    Triangle triangle = new Triangle(5,3,4);

    @Test
    @DisplayName("Area")
    public void area() {
        assertEquals(6, triangle.area(),1);
    }

    @Test
    @DisplayName("Perimeter")
    public void perimeter() {
        assertEquals(12, triangle.perimeter(),1);
    }
}