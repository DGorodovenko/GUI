import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.*;

public class CircleTest {

    Circle circle = new Circle(5);
    @DisplayName("Area")
    @Test
    public void area() {
        assertEquals(78.5, circle.area(),1);
    }
    @DisplayName("Perimeter")
    @Test
    public void perimeter() {
        assertEquals(31.4, circle.perimeter(),1);

    }
}