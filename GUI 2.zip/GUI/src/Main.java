public class Main {
    public static void main(String[] args)
    {
        double width = 5;
        double length = 7;
        Geometricprimitive rectangle = new Rectangle(width, length);
        System.out.println("Rectangle width: " + width + " and length: " + length
                + "\nResulting area: " + rectangle.area()
                + "\nResulting perimeter: " + rectangle.perimeter() + "\n");
    
        double side = 5;
        Geometricprimitive square = new Square(side);
        System.out.println("Square width: " + side + " and length: " + side
                + "\nResulting area: " + square.area()
                + "\nResulting perimeter: " + square.perimeter() + "\n");
       
                // Circle test
        double radius = 5;
        Geometricprimitive circle = new Circle(radius);
        System.out.println("Circle radius: " + radius
            + "\nResulting Area: " + circle.area()
            + "\nResulting Perimeter: " + circle.perimeter() + "\n");

        // Triangle test
        double a = 5, b = 3, c = 4;
        Geometricprimitive triangle = new Triangle(a,b,c);
        System.out.println("Triangle sides lengths: " + a + ", " + b + ", " + c
                + "\nResulting Area: " + triangle.area()
                + "\nResulting Perimeter: " + triangle.perimeter() + "\n");

        //Trapezum
        double sideA = 5, sideB = 3, sideC = 4, sideD = 8, heightT = 4;
        Geometricprimitive trapezum = new Trapezium(sideA, sideB, sideC, sideD, heightT);
        System.out.println("Trapezum sides lengths: " + sideA + ", " + sideB + ", " + sideC + ", " 
        + sideD + " and height: " + heightT + "\nResulting Area: " + trapezum.area()
                + "\nResulting Perimeter: " + trapezum.perimeter() + "\n");
        
                //
                //Trapezum
        double base = 5, sideP = 3, heightP = 4;
        Geometricprimitive parallelogram = new Parallelogram(base, sideP, heightP);
        System.out.println("Parallelogram sides lengths: " + base + ", " + sideP + ", " + " and height: " + heightP + "\nResulting Area: " + parallelogram.area()
                + "\nResulting Perimeter: " + parallelogram.perimeter() + "\n");

        double ad = 5, q = 3, p = 4;
        Geometricprimitive diamond = new Diamond(ad, p, q);
        System.out.println("Diamond diagonals lengths: " + p + ", " + q + ", " + " and side: " + ad + "\nResulting Area: " + diamond.area()
                + "\nResulting Perimeter: " + diamond.perimeter() + "\n");
    }
}