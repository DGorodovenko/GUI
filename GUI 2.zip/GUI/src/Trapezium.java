class Trapezium extends Geometricprimitive{
 
    private final double sideA, sideB,sideC, sideD, heightT;
    
    public Trapezium() {
      this(1,1,1,1,1);
   }
    public Trapezium(double sideA, double sideB, double sideC, double sideD, double heightT) {
      this.sideA = sideA;
      this.sideB = sideB;
      this.sideC = sideC;
      this.sideD = sideD;
      this.heightT = heightT;
   }
  @Override
  public double area() {
      return ((sideA + sideB)/2) * heightT;
  }

  @Override
  public double perimeter() {
      return sideA + sideB + sideC + sideD;
  }

}