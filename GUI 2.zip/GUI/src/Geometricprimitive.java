abstract class Geometricprimitive{

    public abstract double area();
    public abstract double perimeter();

}