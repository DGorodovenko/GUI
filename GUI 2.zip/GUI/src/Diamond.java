class Diamond extends Geometricprimitive{
 
    private final double ad, p, q;
    
    public Diamond() {
      this(1,1,1);
   }
    public Diamond(double ad, double p, double q) {
      this.ad = ad;
      this.p = p;
      this.q = q;
      
   }
  @Override
  public double area() {
      return ad * 4;
  }

  @Override
  public double perimeter() {
      return (p*q)/2;
  }

}