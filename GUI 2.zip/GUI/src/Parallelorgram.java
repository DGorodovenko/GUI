class Parallelogram extends Geometricprimitive{
 
    private final double sideP, base, heightP;
    
    public Parallelogram() {
      this(1,1,1);
   }
    public Parallelogram(double sideP, double base, double heightP) {
      this.sideP = sideP;
      this.base = base;
      this.heightP = heightP;
   }
  @Override
  public double area() {
      return base * heightP;
  }

  @Override
  public double perimeter() {
      return 2 * (sideP + base);
  }

}