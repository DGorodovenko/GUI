abstract class DemoAbstractClass {
    abstract void perimeter();
    abstract void area();
}
  
class ConcreteClass extends DemoAbstractClass {
    

    @Override
    void perimeter() {
        // TODO Auto-generated method stub
        
    }

    @Override
    void area() {
         
        
    }
}
  
public class JavaApplication {
    public static void main(String[] args)
    {
        ConcreteClass S = new ConcreteClass();
        S.area();
        S.perimeter();
    }
}