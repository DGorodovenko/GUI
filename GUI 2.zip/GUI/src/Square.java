class Square extends Geometricprimitive{

 private final double side;
    public Square() { this(1); }
    public Square(double side) { this.side = side; }

@Override
  public double area() { return side * side; }

  public double perimeter() { return 4 * side; }

}